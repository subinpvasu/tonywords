<?php
/*
 *  Mail : subinpvasu@gmail.com
 *  Skype : subinpvasu 
 *  AdWords API integration
 */

?>
<a href="report_download.php" style="margin: 20px;">Report Download</a>
<a href="bidupdate.php">Bid Update</a>
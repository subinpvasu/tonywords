<?php
/*
 *  Mail : subinpvasu@gmail.com
 *  Skype : subinpvasu 
 *  AdWords API integration
 */
 
class Credentials{
    public static $MASTER_ID = '463-244-0190';
//    public static $ACCOUNT_ID = '4958091067';
    public static $CLIENT_ID = '246417427631-jhtj99h7jpgq4skhmr51vj4pktkrb5qq.apps.googleusercontent.com';
    public static $CLIENT_SECRET = 'umkLwHGcpFYWzby4BHoOVL1j';
    public static $DEVELOPER_TOKEN = 'VuUkDoAPfFhYTbAuOMSXpg';
    public static $REFRESH_TOKEN = '1/jILa9xPHWZS1Wc6wjyI-3nS6ORVo_CfLECQJZ_Hdgf0XeHNb64_3lTgGdQfxnXPn';
    public static $STATUS_FIELD = 16;
    public static $PAGE_LIMIT = 500;
    public static $MULTIPLIER = 1000000;
    
 
            
}
